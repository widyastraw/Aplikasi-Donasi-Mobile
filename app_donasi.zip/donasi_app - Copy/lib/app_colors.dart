import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFFA7C7E7);
  static const secondary = Color(0xFFD6E6F2);
  static const accent = Color(0xFF6FA3D3);
  static const background = Color(0xFFF4F9FF);
}