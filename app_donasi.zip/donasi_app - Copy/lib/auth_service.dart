import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
 
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
 
  
  User? get currentUser => _auth.currentUser;
 
  
  Stream<User?> get authStateChanges => _auth.authStateChanges();
 
  // Login
  Future<User?> login(String email, String password) async {
    try {
      var result = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      return result.user;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }
 
  // Register
  Future<User?> register(String nama, String email, String password) async {
    try {
      var result = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
 
      // Simpan data user ke Firestore
      if (result.user != null) {
        await _db.collection('users').doc(result.user!.uid).set({
          'nama': nama,
          'email': email.trim(),
          'role': 'user',
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
 
      return result.user;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthError(e);
    }
  }
 
  // Logout
  Future<void> logout() async {
    await _auth.signOut();
  }
 
  // Handle error Firebase Auth
  String _handleAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'Email tidak ditemukan.';
      case 'wrong-password':
        return 'Password salah.';
      case 'email-already-in-use':
        return 'Email sudah digunakan.';
      case 'weak-password':
        return 'Password terlalu lemah (min. 6 karakter).';
      case 'invalid-email':
        return 'Format email tidak valid.';
      default:
        return 'Terjadi kesalahan: ${e.message}';
    }
  }
  Future<String> getUserRole() async {
  final user = _auth.currentUser;
  if (user == null) return 'user';

  final doc = await _db.collection('users').doc(user.uid).get();
  return doc.data()?['role'] ?? 'user';
}
}