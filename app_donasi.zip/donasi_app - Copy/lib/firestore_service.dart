import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // ================= CAMPAIGNS =================

  Stream<QuerySnapshot> getCampaigns() {
    return _db
        .collection('campaigns')
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Future<void> addCampaign({
    required String title,
    required String description,
    required int target,
    required String imageUrl,
  }) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('Harus login');

    final doc = await _db.collection('users').doc(user.uid).get();
    final role = doc.data()?['role'];

    if (role != 'admin') {
      throw Exception('Hanya admin yang bisa tambah campaign');
    }

    await _db.collection('campaigns').add({
      'title': title,
      'description': description,
      'target': target,
      'collected': 0,
      'imageUrl': imageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteCampaign(String campaignId) async {
    await _db.collection('campaigns').doc(campaignId).delete();
  }

  // ================= DONASI =================

  Future<void> donate({
    required String campaignId,
    required int amount,
  }) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('Harus login');

    final campaignRef = _db.collection('campaigns').doc(campaignId);

    await _db.runTransaction((transaction) async {
      final snapshot = await transaction.get(campaignRef);

      if (!snapshot.exists) throw Exception('Campaign tidak ditemukan');

      final int current = snapshot['collected'] ?? 0;

      transaction.update(campaignRef, {
        'collected': current + amount,
      });
    });

    // 🔥 SIMPAN RIWAYAT DONASI
    await _db.collection('donations').add({
      'userId': user.uid,
      'campaignId': campaignId,
      'amount': amount,
      'date': FieldValue.serverTimestamp(),
    });
  }

  // ================= RIWAYAT =================

  Stream<QuerySnapshot> getDonationHistory() {
    final user = _auth.currentUser;

    if (user == null) {
      return const Stream.empty();
    }

    // 🔥 TANPA orderBy dulu biar tidak kena index error
    return _db
        .collection('donations')
        .where('userId', isEqualTo: user.uid)
        .snapshots();
  }
}