import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;

class CloudinaryService {
  final String cloudName = 'dsaymg3sv';
  final String uploadPreset = 'donasi_app';

  Future<String> uploadImage(File file) async {
    final url =
        Uri.parse('https://api.cloudinary.com/v1_1/$cloudName/image/upload');

    final request = http.MultipartRequest('POST', url);

    request.fields['upload_preset'] = uploadPreset;
    request.files.add(await http.MultipartFile.fromPath('file', file.path));

    final response = await request.send();
    final res = await http.Response.fromStream(response);

    if (response.statusCode == 200) {
      final data = json.decode(res.body);
      return data['secure_url']; // ✅ URL gambar
    } else {
      print("UPLOAD ERROR: ${res.body}");
      throw Exception('Gagal upload ke Cloudinary');
    }
  }
}