import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'firestore_service.dart';
import 'cloudinary_service.dart';
import 'app_colors.dart';

class AddCampaignScreen extends StatefulWidget {
  const AddCampaignScreen({super.key});

  @override
  State<AddCampaignScreen> createState() =>
      _AddCampaignScreenState();
}

class _AddCampaignScreenState extends State<AddCampaignScreen> {
  final title = TextEditingController();
  final desc = TextEditingController();
  final target = TextEditingController();

  final firestore = FirestoreService();
  final cloud = CloudinaryService();

  File? image;
  bool loading = false;

  Future pick() async {
    final picked = await ImagePicker()
        .pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => image = File(picked.path));
    }
  }

  Future submit() async {
    setState(() => loading = true);

    final url = await cloud.uploadImage(image!);

    await firestore.addCampaign(
      title: title.text,
      description: desc.text,
      target: int.parse(target.text),
      imageUrl: url,
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Tambah Campaign')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            GestureDetector(
              onTap: pick,
              child: Container(
                height: 150,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: image == null
                    ? const Icon(Icons.add_a_photo)
                    : Image.file(image!, fit: BoxFit.cover),
              ),
            ),

            const SizedBox(height: 16),

            TextField(controller: title, decoration: _input('Judul')),
            const SizedBox(height: 10),
            TextField(controller: desc, decoration: _input('Deskripsi')),
            const SizedBox(height: 10),
            TextField(controller: target, decoration: _input('Target')),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: loading ? null : submit,
              child: const Text('Simpan'),
            )
          ],
        ),
      ),
    );
  }

  InputDecoration _input(String h) => InputDecoration(
        hintText: h,
        filled: true,
        fillColor: Colors.white,
        border:
            OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      );
}