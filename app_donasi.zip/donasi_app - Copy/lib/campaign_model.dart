import 'package:cloud_firestore/cloud_firestore.dart';
 
class Campaign {
  final String id;
  final String title;
  final String description;
  final int target;
  final int collected;
  final String imageUrl;
  final DateTime? createdAt;
 
  Campaign({
    required this.id,
    required this.title,
    required this.description,
    required this.target,
    required this.collected,
    required this.imageUrl,
    this.createdAt,
  });
 
  // Buat Campaign dari dokumen Firestore
  factory Campaign.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Campaign(
      id: doc.id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      target: data['target'] ?? 0,
      collected: data['collected'] ?? 0,
      imageUrl: data['imageUrl'] ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
    );
  }
 
  // Persentase progress donasi
  double get progressPercent {
    if (target == 0) return 0;
    return (collected / target).clamp(0.0, 1.0);
  }
 
  // Format angka ke Rupiah
  String get collectedFormatted => _formatRupiah(collected);
  String get targetFormatted => _formatRupiah(target);
 
  static String _formatRupiah(int amount) {
    return 'Rp ${amount.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';
  }
}