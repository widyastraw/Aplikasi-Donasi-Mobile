import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'auth_service.dart';
import 'firestore_service.dart';
import 'campaign_model.dart';
import 'login_screen.dart';
import 'add_campaign_screen.dart';
import 'campaign_detail_screen.dart';
import 'donation_history_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _authService = AuthService();
  final _firestoreService = FirestoreService();

  String _role = 'user';
  bool _loadingRole = true;

  @override
  void initState() {
    super.initState();
    _loadRole();
  }

  Future<void> _loadRole() async {
    final role = await _authService.getUserRole();
    setState(() {
      _role = role;
      _loadingRole = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loadingRole) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_role == 'admin'
            ? 'Admin Panel 👑'
            : 'DonasiKu 💙'),
            actions: [
            if (_role != 'admin')
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => const DonationHistoryScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await _authService.logout();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              );
            },
          ),
        ],
      ),

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER MODERN
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFA7C7E7), Color(0xFF6FA3D3)],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text(
              'Mari bantu sesama 🤝',
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
          ),

          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Campaign Aktif',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),

          const SizedBox(height: 10),

          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _firestoreService.getCampaigns(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final campaigns = snapshot.data!.docs
                    .map((doc) => Campaign.fromFirestore(doc))
                    .toList();

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: campaigns.length,
                  itemBuilder: (context, index) {
                    final c = campaigns[index];

                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CampaignDetailScreen(campaign: c),
                        ),
                      ),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.06),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            )
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(18)),
                              child: Image.network(
                                c.imageUrl,
                                height: 160,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                            ),

                            Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(c.title,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold)),

                                  const SizedBox(height: 8),

                                  LinearProgressIndicator(
                                    value: c.progressPercent,
                                    minHeight: 8,
                                    borderRadius: BorderRadius.circular(10),
                                  ),

                                  const SizedBox(height: 6),

                                  Text(
                                    '${c.collectedFormatted} / ${c.targetFormatted}',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),

      // 🔥 BUTTON HANYA ADMIN
      floatingActionButton: _role == 'admin'
          ? FloatingActionButton(
              backgroundColor: const Color(0xFF6FA3D3),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddCampaignScreen()),
              ),
              child: const Icon(Icons.add),
            )
          : null,
    );
  }
}