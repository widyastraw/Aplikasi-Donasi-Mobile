import 'package:cloud_firestore/cloud_firestore.dart';
 
class UserModel {
  final String uid;
  final String nama;
  final String email;
  final String role;
 
  UserModel({
    required this.uid,
    required this.nama,
    required this.email,
    required this.role,
  });
 
  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      nama: data['nama'] ?? '',
      email: data['email'] ?? '',
      role: data['role'] ?? 'user',
    );
  }
 
  bool get isAdmin => role == 'admin';
}